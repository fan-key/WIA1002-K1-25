public interface Shape {
    public double calculateVolume();
    public double calculateSurfaceArea();
}
